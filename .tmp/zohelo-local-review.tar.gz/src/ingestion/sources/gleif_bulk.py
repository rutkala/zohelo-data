"""Official bulk extractor for GLEIF (Global Legal Entity Identifier Foundation) (CD-015).

In accordance with ADR 0009 (Native-Only Landing):
- Downloads official daily Golden Copy packages from GLEIF:
  1. LEI Level 1 (lei2): Complete Legal Entity reference records globally (~500 MB zip)
  2. LEI Level 2 (rr): Relationship Records (who owns whom: direct/ultimate parent) (~25 MB zip)
  3. LEI Level 2 (repex): Reporting Exceptions (~60 MB zip)
- Computes SHA-256 and MD5 checksums for byte integrity
- Stores native byte-for-byte archives in 01_landing/gleif/native/bulk/<date>/
- Generates durable completion receipt in 06_control/source_campaigns/gleif/
- Strictly decoupled from downstream Bronze parsing
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import logging
import os
from pathlib import Path
import sys
import time
from typing import Any
import urllib.request
import urllib.error

REPO_ROOT = Path(__file__).resolve().parents[3]
SRC_DIR = REPO_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from storage_manager import StorageManager
from googleapiclient.http import MediaFileUpload

logger = logging.getLogger("gleif_bulk")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)

GLEIF_DATASETS = [
    {
        "dataset_key": "lei2",
        "url": "https://goldencopy.gleif.org/api/v2/golden-copies/publishes/lei2/latest.csv",
        "description": "GLEIF Golden Copy Level 1 LEI records (global entity reference data)",
        "default_filename": "gleif_goldencopy_lei2.csv.zip",
    },
    {
        "dataset_key": "rr",
        "url": "https://goldencopy.gleif.org/api/v2/golden-copies/publishes/rr/latest.csv",
        "description": "GLEIF Golden Copy Level 2 Relationship Records (who owns whom)",
        "default_filename": "gleif_goldencopy_rr.csv.zip",
    },
    {
        "dataset_key": "repex",
        "url": "https://goldencopy.gleif.org/api/v2/golden-copies/publishes/repex/latest.csv",
        "description": "GLEIF Golden Copy Level 2 Reporting Exceptions",
        "default_filename": "gleif_goldencopy_repex.csv.zip",
    },
]


def _hash_file(path: Path) -> tuple[str, str]:
    d_sha = hashlib.sha256()
    d_md5 = hashlib.md5()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            d_sha.update(chunk)
            d_md5.update(chunk)
    return d_sha.hexdigest(), d_md5.hexdigest()


def _escape_query(value: str) -> str:
    return value.replace("\\", "\\\\").replace("'", "\\'")


def _resolve_or_create_folder(storage: StorageManager, folder_name: str, parent_id: str) -> str:
    query = f"name='{_escape_query(folder_name)}' and '{_escape_query(parent_id)}' in parents and mimeType='application/vnd.google-apps.folder' and trashed=false"
    existing = storage.drive_service.files().list(q=query, spaces="drive", fields="files(id,name)").execute().get("files", [])
    if existing:
        return existing[0]["id"]
    created = storage.drive_service.files().create(
        body={"name": folder_name, "mimeType": "application/vnd.google-apps.folder", "parents": [parent_id]},
        fields="id,name",
    ).execute(num_retries=4)
    return created["id"]


def _upload_file_to_drive(
    storage: StorageManager,
    local_path: Path,
    name: str,
    parent_id: str,
    mime_type: str = "application/zip",
) -> dict[str, Any]:
    sha256_hex, md5_hex = _hash_file(local_path)
    query = f"name='{_escape_query(name)}' and '{_escape_query(parent_id)}' in parents and trashed=false"
    existing = storage.drive_service.files().list(
        q=query, spaces="drive", fields="files(id,name,size,md5Checksum,appProperties)"
    ).execute().get("files", [])

    if existing:
        item = existing[0]
        props = item.get("appProperties") or {}
        if (
            props.get("sha256") == sha256_hex
            and item.get("md5Checksum") == md5_hex
            and int(item.get("size", -1)) == local_path.stat().st_size
        ):
            logger.info("File %s already exists on Drive with matching hash. Reusing.", name)
            return {"id": item["id"], "name": name, "size": local_path.stat().st_size, "reused": True}
        storage.drive_service.files().delete(fileId=item["id"]).execute()

    media = MediaFileUpload(str(local_path), mimetype=mime_type, resumable=True)
    body = {"name": name, "parents": [parent_id], "appProperties": {"sha256": sha256_hex}}
    created = storage.drive_service.files().create(
        body=body, media_body=media, fields="id,name,size,md5Checksum"
    ).execute(num_retries=4)
    logger.info("Uploaded %s to Drive (id=%s, size=%d bytes)", name, created["id"], local_path.stat().st_size)
    return {"id": created["id"], "name": name, "size": local_path.stat().st_size, "reused": False}


def _download_stream(url: str, target_path: Path, chunk_size: int = 1048576) -> tuple[str, str]:
    temp_target = target_path.with_suffix(".tmp")
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},
    )
    logger.info("Downloading %s -> %s...", url, target_path.name)
    start_t = time.time()
    downloaded_bytes = 0
    with urllib.request.urlopen(req, timeout=300) as response, temp_target.open("wb") as out_f:
        final_url = response.geturl()
        publish_date = response.headers.get("x-gleif-publish-date", "")
        total_len = int(response.headers.get("Content-Length", 0))
        while True:
            chunk = response.read(chunk_size)
            if not chunk:
                break
            out_f.write(chunk)
            downloaded_bytes += len(chunk)
            if total_len > 0 and downloaded_bytes % (chunk_size * 25) < chunk_size:
                logger.info(
                    "  %s: %d / %d MB (%.1f%%)",
                    target_path.name,
                    downloaded_bytes // (1024 * 1024),
                    total_len // (1024 * 1024),
                    100.0 * downloaded_bytes / total_len,
                )
    temp_target.replace(target_path)
    elapsed = time.time() - start_t
    mb = downloaded_bytes / (1024 * 1024)
    logger.info("Downloaded %s (%.1f MB in %.1fs, %.2f MB/s)", target_path.name, mb, elapsed, mb / max(elapsed, 0.1))
    return final_url, publish_date


def run_gleif_ingestion(
    workspace: Path,
    datasets: list[str] | None = None,
    allow_codespace: bool = False,
    skip_download: bool = False,
    skip_upload: bool = False,
) -> dict[str, Any]:
    workspace.mkdir(parents=True, exist_ok=True)
    selected_keys = set(datasets) if datasets else {"lei2", "rr", "repex"}
    selected_configs = [d for d in GLEIF_DATASETS if d["dataset_key"] in selected_keys]

    downloaded_files = []
    latest_publish_date = ""

    for cfg in selected_configs:
        fname = cfg["default_filename"]
        target = workspace / fname
        final_url = cfg["url"]
        pub_date = ""
        if not (skip_download and target.exists() and target.stat().st_size > 0):
            final_url, pub_date = _download_stream(cfg["url"], target)
            if pub_date:
                latest_publish_date = pub_date

        sha256_hex, md5_hex = _hash_file(target)
        downloaded_files.append({
            "dataset_key": cfg["dataset_key"],
            "target_path": target,
            "filename": fname,
            "final_url": final_url,
            "publish_date": pub_date,
            "size_bytes": target.stat().st_size,
            "sha256": sha256_hex,
            "md5": md5_hex,
            "description": cfg["description"],
        })

    snapshot_date = datetime.now(timezone.utc).strftime("%Y%m%d")

    in_actions = os.environ.get("GITHUB_ACTIONS") == "true"
    can_upload = (in_actions or allow_codespace) and not skip_upload

    if can_upload:
        if allow_codespace:
            os.environ["ZOHELO_ALLOW_PRODUCTION_WRITES"] = "true"
        storage = StorageManager(allow_interactive_auth=False)
        storage.resolve_root(create=False)
        storage.authorize_writes()

        landing_id = storage.resolve_zone("landing")
        gleif_landing_id = _resolve_or_create_folder(storage, "gleif", landing_id)
        native_id = _resolve_or_create_folder(storage, "native", gleif_landing_id)
        bulk_id = _resolve_or_create_folder(storage, "bulk", native_id)
        date_folder_id = _resolve_or_create_folder(storage, snapshot_date, bulk_id)

        control_id = storage.resolve_zone("control")
        campaigns_id = _resolve_or_create_folder(storage, "source_campaigns", control_id)
        gleif_control_id = _resolve_or_create_folder(storage, "gleif", campaigns_id)

        drive_archives = []
        for item in downloaded_files:
            uploaded = _upload_file_to_drive(
                storage,
                item["target_path"],
                item["filename"],
                date_folder_id,
                mime_type="application/zip",
            )
            drive_archives.append({
                "dataset_key": item["dataset_key"],
                "file_name": item["filename"],
                "drive_id": uploaded["id"],
                "size_bytes": item["size_bytes"],
                "sha256": item["sha256"],
                "md5": item["md5"],
                "reused": uploaded["reused"],
                "url": item["final_url"],
                "description": item["description"],
            })

        receipt_data = {
            "source_id": "gleif",
            "snapshot_date": snapshot_date,
            "publish_date": latest_publish_date,
            "extracted_at_utc": datetime.now(timezone.utc).isoformat(),
            "load_complete": True,
            "catalogue_exhausted": True,
            "archives": drive_archives,
        }
        receipt_path = workspace / "gleif_receipt.json"
        receipt_path.write_text(json.dumps(receipt_data, indent=2), encoding="utf-8")
        _upload_file_to_drive(storage, receipt_path, "gleif_receipt.json", gleif_control_id, mime_type="application/json")
        logger.info("GLEIF Landing complete and receipt uploaded to Drive.")
        return receipt_data

    return {
        "status": "downloaded_locally",
        "snapshot_date": snapshot_date,
        "files": [f["filename"] for f in downloaded_files],
    }


def main():
    parser = argparse.ArgumentParser(description="GLEIF Golden Copy Bulk Extractor")
    parser.add_argument("--workspace", type=str, default="portal/test-results/gleif")
    parser.add_argument("--datasets", nargs="*", default=None, help="Datasets to extract: lei2 rr repex")
    parser.add_argument("--allow-codespace", action="store_true")
    parser.add_argument("--skip-download", action="store_true")
    parser.add_argument("--skip-upload", action="store_true")
    args = parser.parse_args()

    res = run_gleif_ingestion(
        workspace=Path(args.workspace).resolve(),
        datasets=args.datasets,
        allow_codespace=args.allow_codespace,
        skip_download=args.skip_download,
        skip_upload=args.skip_upload,
    )
    print(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()
