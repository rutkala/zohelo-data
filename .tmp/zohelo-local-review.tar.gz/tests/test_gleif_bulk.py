from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import MagicMock, patch

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = REPO_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))
SOURCES_DIR = SRC_DIR / "ingestion" / "sources"
if str(SOURCES_DIR) not in sys.path:
    sys.path.insert(0, str(SOURCES_DIR))

from gleif_bulk import (
    _hash_file,
    run_gleif_ingestion,
    GLEIF_DATASETS,
)


class TestGleifBulk(unittest.TestCase):
    def test_hash_file(self):
        with tempfile.NamedTemporaryFile() as tmp:
            tmp.write(b"sample_gleif_zip_content")
            tmp.flush()
            sha, md5 = _hash_file(Path(tmp.name))
            self.assertEqual(len(sha), 64)
            self.assertEqual(len(md5), 32)

    def test_gleif_datasets_definitions(self):
        keys = {d["dataset_key"] for d in GLEIF_DATASETS}
        self.assertIn("lei2", keys)
        self.assertIn("rr", keys)
        self.assertIn("repex", keys)

    @patch("gleif_bulk._download_stream")
    def test_run_gleif_ingestion_local(self, mock_download):
        def fake_download(url, target_path):
            target_path.write_bytes(b"PK_fake_zip_bytes")
            return "https://goldencopy.gleif.org/fake.zip", "2026-09-20T16:00:00Z"

        mock_download.side_effect = fake_download

        with tempfile.TemporaryDirectory() as tmp_dir:
            res = run_gleif_ingestion(
                workspace=Path(tmp_dir),
                datasets=["rr"],
                skip_upload=True,
            )
            self.assertEqual(res["status"], "downloaded_locally")
            self.assertEqual(res["files"], ["gleif_goldencopy_rr.csv.zip"])


if __name__ == "__main__":
    unittest.main()
