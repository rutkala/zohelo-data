"""Exercise GUS DBW (Dziedzinowe Bazy Wiedzy) platform dbt models and marts offline with DuckDB."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import duckdb

REPO_ROOT = Path(__file__).resolve().parents[1]


class TestDBWPlatformModels(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp_dir = tempfile.TemporaryDirectory(prefix="zohelo-dbw-test-")
        cls.root = Path(cls.temp_dir.name)
        cls.data_root = cls.root / "data"
        cls.bronze_dir = cls.data_root / "02_bronze" / "gus_dbw"
        (cls.bronze_dir / "taxonomy").mkdir(parents=True, exist_ok=True)
        (cls.bronze_dir / "metadata").mkdir(parents=True, exist_ok=True)
        (cls.bronze_dir / "dictionaries").mkdir(parents=True, exist_ok=True)
        (cls.bronze_dir / "observations").mkdir(parents=True, exist_ok=True)
        cls.database = cls.root / "dbw.duckdb"
        cls.target = cls.root / "target"

        con = duckdb.connect()

        # 1. Indicators taxonomy
        con.execute(f"""
            CREATE TABLE ind AS
            SELECT
                1023::BIGINT AS indicator_id,
                'Eksport towarów i usług' AS indicator_name,
                'Exports of goods and services' AS indicator_name_en,
                10::BIGINT AS domain_id,
                'Handel zagraniczny' AS domain_name,
                'Foreign trade' AS domain_name_en,
                1::BIGINT AS area_id,
                'Gospodarka' AS area_name,
                'Economy' AS area_name_en,
                '2026-09-20 12:00:00'::VARCHAR AS processed_at_utc
        """)
        con.execute(f"COPY ind TO '{cls.bronze_dir / 'taxonomy' / 'br_dbw_indicators.parquet'}' (FORMAT PARQUET)")

        # 2. Indicators metadata
        con.execute(f"""
            CREATE TABLE meta AS
            SELECT
                1023::BIGINT AS indicator_id,
                'Eksport' AS metric_name,
                'Exports' AS metric_name_en,
                'Wartość eksportu towarów i usług w cenach bieżących' AS description,
                'Roczna' AS frequency,
                'mln zł' AS measure_unit,
                'GUS' AS data_source,
                'Ustawa o statystyce publicznej' AS legal_basis,
                '2026-01-15' AS last_update,
                '2026-09-20 12:00:00'::VARCHAR AS processed_at_utc
        """)
        con.execute(f"COPY meta TO '{cls.bronze_dir / 'metadata' / 'br_dbw_metadata.parquet'}' (FORMAT PARQUET)")

        # 3. Dictionaries
        con.execute(f"""
            CREATE TABLE dicts AS
            SELECT
                1023::BIGINT AS indicator_id,
                'id_wymiar_1' AS column_name,
                'Rodzaje towarów' AS dictionary_name,
                33617::BIGINT AS element_id,
                'Ogółem' AS element_name,
                '2026-09-20 12:00:00'::VARCHAR AS processed_at_utc
        """)
        con.execute(f"COPY dicts TO '{cls.bronze_dir / 'dictionaries' / 'br_dbw_dictionaries.parquet'}' (FORMAT PARQUET)")

        # 4. Observations
        con.execute(f"""
            CREATE TABLE obs AS
            SELECT
                1023::BIGINT AS indicator_id,
                1075::BIGINT AS przekroj_id,
                2::BIGINT AS wymiar_1,
                33617::BIGINT AS pozycja_1,
                CAST(NULL AS BIGINT) AS wymiar_2,
                CAST(NULL AS BIGINT) AS pozycja_2,
                CAST(NULL AS BIGINT) AS wymiar_3,
                CAST(NULL AS BIGINT) AS pozycja_3,
                CAST(NULL AS BIGINT) AS wymiar_4,
                CAST(NULL AS BIGINT) AS pozycja_4,
                CAST(NULL AS BIGINT) AS wymiar_5,
                CAST(NULL AS BIGINT) AS pozycja_5,
                CAST(NULL AS BIGINT) AS wymiar_6,
                CAST(NULL AS BIGINT) AS pozycja_6,
                CAST(NULL AS BIGINT) AS wymiar_7,
                CAST(NULL AS BIGINT) AS pozycja_7,
                CAST(NULL AS BIGINT) AS wymiar_8,
                CAST(NULL AS BIGINT) AS pozycja_8,
                CAST(NULL AS BIGINT) AS wymiar_9,
                CAST(NULL AS BIGINT) AS pozycja_9,
                282::INTEGER AS okres_id,
                1::INTEGER AS sposob_prezentacji_miara_id,
                2022::INTEGER AS period_year,
                '123456.78' AS wartosc_raw,
                123456.78::DOUBLE AS wartosc_numeric,
                2::INTEGER AS precyzja,
                CAST(NULL AS INTEGER) AS brak_wartosci_id,
                CAST(NULL AS INTEGER) AS tajnosci_id,
                CAST(NULL AS INTEGER) AS flaga_id,
                'Baza_1023.zip' AS raw_archive_file,
                1::BIGINT AS source_row_number,
                '2026-09-20 12:00:00'::VARCHAR AS processed_at_utc
        """)
        con.execute(f"COPY obs TO '{cls.bronze_dir / 'observations' / 'part_1023.parquet'}' (FORMAT PARQUET)")
        con.close()

        # Run dbt build
        env = dict(os.environ)
        env.update(
            ZOHELO_DATA_ROOT=str(cls.data_root),
            ZOHELO_DUCKDB_PATH=str(cls.database),
            DBT_SEND_ANONYMOUS_USAGE_STATS="false",
            DO_NOT_TRACK="1",
        )
        cmd = [
            "dbt", "build",
            "--profiles-dir", str(REPO_ROOT),
            "--target-path", str(cls.target),
            "--select",
            "+stg_dbw_indicators",
            "+stg_dbw_metadata",
            "+stg_dbw_dictionaries",
            "+stg_dbw_observations",
            "+dim_dbw_indicator",
            "+fact_dbw_observations",
            "+mart_dbw_coverage",
            "--vars", '{"enable_gus_dbw": true}',
            "--threads", "1",
            "--no-partial-parse",
        ]
        res = subprocess.run(cmd, cwd=REPO_ROOT, env=env, capture_output=True, text=True)
        if res.returncode != 0:
            raise AssertionError(f"DBW dbt build failed:\nSTDOUT:\n{res.stdout}\nSTDERR:\n{res.stderr}")

    @classmethod
    def tearDownClass(cls):
        cls.temp_dir.cleanup()

    def test_dim_dbw_indicator(self):
        con = duckdb.connect(str(self.database))
        res = con.execute('SELECT indicator_key, indicator_name, measure_unit, domain_name FROM "04_gold"."dim_dbw_indicator"').fetchall()
        con.close()
        self.assertEqual(len(res), 1)
        self.assertEqual(res[0], (1023, "Eksport towarów i usług", "mln zł", "Handel zagraniczny"))

    def test_fact_dbw_observations(self):
        con = duckdb.connect(str(self.database))
        res = con.execute('SELECT indicator_key, period_year, wartosc_numeric, raw_archive_file FROM "04_gold"."fact_dbw_observations"').fetchall()
        con.close()
        self.assertEqual(len(res), 1)
        self.assertEqual(res[0], (1023, 2022, 123456.78, "Baza_1023.zip"))

    def test_mart_dbw_coverage(self):
        con = duckdb.connect(str(self.database))
        res = con.execute('SELECT total_indicators, total_observations, earliest_year, latest_year FROM "04_gold"."mart_dbw_coverage"').fetchall()
        con.close()
        self.assertEqual(len(res), 1)
        self.assertEqual(res[0], (1, 1, 2022, 2022))


if __name__ == "__main__":
    unittest.main()
